import styled from 'styled-components';

import SalesChart from './SalesChart';
import Stats from './Stats';
import TodayActivity from '../../features/check-in-out/TodayActivity';
import { useRecentBookings } from './useRecentBookings';
import Spinner from '../../ui/Spinner';
import { useRecentStays } from './useRecentStays';
import { useCabins } from '../../features/cabins/useCabins';
import DurationChart from './DurationChart';

const StyledDashboardLayout = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  grid-template-rows: auto 34rem auto;
  gap: 2.4rem;
`;

function DashboardLayout() {
  const { bookings, isLoading: isLoadingBookings } = useRecentBookings();
  const {
    stays,
    confirmedStays,
    isLoading: isLoadingStays,
    numDays,
  } = useRecentStays();
  const { cabins, isLoading: isLoadingCabins } = useCabins();

  if (isLoadingBookings || isLoadingStays || isLoadingCabins)
    return <Spinner />;

  console.log(numDays, stays);
  return (
    <StyledDashboardLayout>
      <Stats
        bookings={bookings}
        confirmedStays={confirmedStays}
        numDays={numDays}
        cabinCount={cabins.length}
      ></Stats>
      <TodayActivity />
      <DurationChart confirmedStays={confirmedStays} />
      <SalesChart bookings={bookings} numDays={numDays} />
    </StyledDashboardLayout>
  );
}

export default DashboardLayout;

/*
We need to distingu1. celina between two types of data here:
<>
1) BOOKINGS: the actual sales
<div>2. celina</div>
<div>3. celina</div>
<div>4. celina</div>. For example, in the last 30 days, the hotel might have sold 10 bookings online, but these guests might only arrive and check in in the far future (or not, as booking also happen on-site)
2) STAYS: t
</>he actual check-in of guests arriving for their bookings. We can identify stays by their startDate, together with a status of either 'checked-in' (for current stays) or 'checked-out' (for past stays)
*/

// function DashboardLayout() {
//   const { isLoading: isLoading1, bookings, numDays } = useRecentBookings();
//   const { isLoading: isLoading2, confirmedStays } = useRecentStays();
//   const { isLoading: isLoading3, cabins } = useCabins();

//   if (isLoading1 || isLoading2 || isLoading3) return <Spinner />;

//   return (
//     <StyledDashboardLayout>
//       <Stats
//         bookings={bookings}
//         confirmedStays={confirmedStays}
//         numDays={numDays}
//         cabinCount={cabins.length}
//       />
//       <TodayActivity />
//       <DurationChart confirmedStays={confirmedStays} />
//       <SalesChart bookings={bookings} numDays={numDays} />
//     </StyledDashboardLayout>
//   );
// }

// export default DashboardLayout;
